import React, { useState, Fragment } from 'react';

import ReactFlow, { addEdge, Background, Controls, MiniMap, getBezierPath, getMarkerEnd } from 'react-flow-renderer';

const initialElements = [
    { id: '1', type: 'input', data: { label: 'Mind Node' }, position: { x: 0, y: 0 } }
]
const onLoad = (reactFlowInstance) => {
    reactFlowInstance.fitView();
}

const Card = () => {

    const [elements, setElements] = useState(initialElements);
    //const [elements, setElements] = useState([]);
    const [lastId, setLastId] = useState(1);
    const [name, setName] = useState("")
    const [text, setText] = useState("blank");
    const [removingId, setRemovingId] = useState(0);

    const addNode = () => {
        setElements(e => e.concat({
            //id: (e.length + 1).toString(),
            id: lastId +1,
            data: { label: `${name}` },
            position: { x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight }
        }));
    };
    const addNode2 = () => {
        var lId = parseInt(`${lastId}`);
        var node = getImageNode(lId + 1);
        setText(lId);
        setLastId(lId + 1);
        setElements(e => e.concat({
            //id: (e.length + 1).toString(),
            id: lId +1,
            //data: { label: <div><h1>Hello</h1></div> },
            data: { label: node },
            //position: { x: Math.random() * window.innerWidth, y: Math.random() * window.innerHeight }
            position: {x: e[0].position.x + 50, y: e[0].position.y + 50}
        }));
    };
    const onRemove = (nid) => {
        //alert(nid.toString());
        //setText("removing" + nid.toString());
        var newarr = elements.filter(element => element.id !== nid);
        setElements(newarr);
    };
    const getImageNode = (nid) => {
        var x = nid.toString();
        return <div>
            <h3>Node {nid}</h3>
            <button onClick={e=>onRemove(x)}>Click</button>
        </div>
    };

    const onConnect = (params) => {
        //setText(params.source.toString() + params.target.toString());
        var i = 'e' + params.source.toString() + '-' + params.target.toString();
        var s = params.source.toString();
        var t = params.target.toString();
        setElements(e => e.concat({ 
            id: i, 
            source: s, 
            target: t, 
            animated: true }));
    }

    return (
        <Fragment>
            <ReactFlow
                elements={elements}
                onLoad={onLoad}
                style={{ width: '100%', height: '90vh' }}
                onConnect={onConnect}
                connectionLineStyle={{ stroke: "#ddd", strokeWidth: 2 }}
                connectionLineType="bezier"
                snapToGrid={true}
                snapGrid={[16, 16]}
            >
                <Background color="#888" gap={16} />
                <MiniMap />
                <Controls />
            </ReactFlow>

            <div>
                <input type="text"
                    onChange={e => setName(e.target.value)}
                    name="title" />
                <button
                    type="button"
                    onClick={addNode}
                >Add Node</button>
                <button
                    type="button"
                    onClick={addNode2}
                >Add Node</button>
                <h1>{text}</h1>
            </div>
        </Fragment>
    )
}

export default Card;