import logo from './logo.svg';
import './App.css';
import Basic from './Components/Basic';
import Basic2 from './Components/Basic2';
import ReactFlow from 'react-flow-renderer';
import CustomNodeFlow from './Components/CustomNode';

function App() {
  return (
    <div className="App">
      {
        //<CustomNodeFlow/>
      }
      <Basic2 />
    </div>
  );
}

export default App;
